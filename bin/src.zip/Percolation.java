
public class Percolation {

	private boolean grid[][];	//false = closed; true = open
	private WeightedQuickUnionUF uf;
	private int N;
	
	public Percolation(int N) {
		this.N = N;
		grid = new boolean[N][N];
		uf = new WeightedQuickUnionUF(N);
	}

	private void checkBoundaries(int i, int j) {
		if((i < 0) || (i > N)) {
			throw new java.lang.IndexOutOfBoundsException();
		}
	}
	
	public void open(int i, int j) {
		checkBoundaries(i, j);
		grid[i][j] = true;
		
		// check union with layer above
		if(i != 0) {
			if(grid[i-1][j]) {
				uf.union(i, i-1);
			}
		}
		
		// check union with layer below
		if(i != N) {
			if(grid[i+1][j]) {
				uf.union(i, i+1);
			}
		}
	}
	
	public boolean isOpen(int i, int j) {
		checkBoundaries(i, j);
		return grid[i][j];
	}
	
	public boolean isFull(int i, int j) {
		checkBoundaries(i, j);
		return !grid[i][j];
	}
	
	public boolean percolates() {
		return uf.connected(0, N);
	}

}

